/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8
// basic_iserializer.cpp:

// (C) Copyright 2002 Robert Ramey - http://www.rrsd.com . 
// Use, modification and distribution is subject to the Boost Software
// License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision history.

#include <cstddef> // NULL

#define BOOST_ARCHIVE_SOURCE
#include <boost/serialization/config.hpp>

#include <boost/archive/detail/basic_iserializer.hpp>

#ifdef BOOST_MSVC
#undef BOOST_ARCHIVE_DECL
#define BOOST_ARCHIVE_DECL /*comment*/  // for MSVC
#endif

namespace boost {
namespace archive {
namespace detail {

BOOST_ARCHIVE_DECL 
basic_iserializer::basic_iserializer(
    const boost::serialization::extended_type_info & type /*eti*/
) :
    basic_serializer(type),
    m_bpis(nullptr)
{}

BOOST_ARCHIVE_DECL 
basic_iserializer::~basic_iserializer(){}  // NOLINT(hicpp-use-equals-default,modernize-use-equals-default) external code

} // namespace detail
} // namespace archive
} // namespace boost
